#include <cs50.h>
#include <stdio.h>

int main(void) {

    int n = get_int("Please Enter: ");



     double ounces = 128;
    double shower = ounces * 1.5;
     int bottle = 16;
    bottle = shower/bottle;

   do {
       printf("Minute: %d\n", n);
       printf("Bottle: %d\n", bottle*n);

       break;


      }
   while (n >= 0);

   if (n < 0) {
       printf("Error! No such thing exists!\n");
   }

}