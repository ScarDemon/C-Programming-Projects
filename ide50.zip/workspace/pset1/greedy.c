#include <stdio.h>
#include <cs50.h>
#include <math.h>
int main (void) {




printf("O hai! How much change is owed?\n");


float f = get_float();
f = f * 100;
int c = round(f);

while (c < 0) {


    printf("Retry: ");
    f = get_float();
    f = round(f * 100);
     c = f;

}

int coin = 0;
  while (c > 0) {
     if (c > 0 && c >= 25) {
         c = c - 25;
          coin++;
}
     else if (c < 25 &&  c >= 10) {
        c = c - 10;
        coin++;
    }

     else if (c < 10 && c >= 5) {
        c = c - 5;
        coin++;
    }
     else if (c < 5 &&  c >= 1) {
        c = c - 1;
        coin++;
    }

}

printf("%d\n", coin);
}